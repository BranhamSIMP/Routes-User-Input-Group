import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ReadExcelDemo
{
	
	public static void main(String[] args) throws IOException
	{
		Scanner input = new Scanner(System.in);
		System.out.println("What room number would you like to see the data for? If you want gym, enter: 86");
		double roomNum = input.nextDouble();
		String test = ExcelFileReader(roomNum);
		System.out.println(test);
	}
	@SuppressWarnings("deprecation")
	public static String ExcelFileReader(double roomNum) throws IOException {
		FileInputStream file = new FileInputStream(new File("SIMP Teacher Info.xls"));
		String output = "";
		ArrayList<String> input = new ArrayList<String>();
		//Create Workbook instance holding reference to .xlsx file
		HSSFWorkbook workbook = new HSSFWorkbook(file);

		//Get first/desired sheet from the workbook
		HSSFSheet sheet = workbook.getSheetAt(0);
		FormulaEvaluator form = workbook.getCreationHelper().createFormulaEvaluator();
		Row rowStore = null;
		for(Row row : sheet) {
			//System.out.println();
			for(Cell cell : row) {
				if(cell.toString().equals(""+roomNum)){
					
					rowStore = cell.getRow();
					//Check the cell type and format accordingly
					switch (form.evaluateInCell(cell).getCellType())
					{
					case Cell.CELL_TYPE_NUMERIC:
						double number = cell.getNumericCellValue();
						int y = (int)number;
						String yes = Integer.toString(y);
						String z = yes + " ";
						//return z;
						output = output + y + "~";
						//System.out.print(y + "~");
						break;
					case Cell.CELL_TYPE_STRING:
						String yup = cell.getStringCellValue();
						String h = yup + " ";
						//return h;
						output = output + cell.getStringCellValue() + "~";
						//System.out.print(cell.getStringCellValue() + "~");
						break;
					}
				}
				else if(rowStore != null && rowStore.equals(row) ) {
					//Check the cell type and format accordingly
					if(cell ==null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
						output = output + "~";
					}
					switch (form.evaluateInCell(cell).getCellType())
					{
					case Cell.CELL_TYPE_NUMERIC:
						double number = cell.getNumericCellValue();
						int y = (int)number;
						String yes = Integer.toString(y);
						String z = yes + " ";
						//return z;
						output = output + cell.getStringCellValue() + "~";
						//System.out.print(y + "~");
						break;
					case Cell.CELL_TYPE_STRING:
						String yup = cell.getStringCellValue();
						String h = yup + " ";
						//return h ;
						output = output +cell.getStringCellValue() + "~";
						//System.out.print(cell.getStringCellValue() + "~");
						break;
					}
				} 
			}
		}
		//System.out.println();
		file.close();
		return output;
	}
}
