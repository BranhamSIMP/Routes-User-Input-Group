import java.awt.Font;
import java.awt.Image;
import java.awt.MouseInfo;
import java.awt.Point;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import java.awt.Graphics;
import java.awt.Toolkit;

// By Alexander Noffsinger-Kamp, class of 2018

public class classPopup extends JPanel{
	static String teacher;
	static String department;
	static String availability;
	static String clubs;
	static JFrame frame;
	static String roomNumber;
	
	//static JPanel JP;
	
	public static void main(String[] args) throws IOException {
		roomPop("Room " + 72);
		
	}
	
	public void paint(Graphics g){
		
		 Image image = Toolkit.getDefaultToolkit().getImage("fitzvo.jpg");
		   
			JButton direct = new JButton("Direct to");
			JTextArea depart = new JTextArea(department,0,2);
			JTextArea avalib = new JTextArea(availability,0,2);
			JTextArea club = new JTextArea(clubs);
			JLabel placeholder = new JLabel("-");
			depart.setSize(200, 40);
			avalib.setSize(200, 40);
			club.setSize(200, 40);
			direct.setSize(120, 30);
			
			 depart.setEditable(false);
			 club.setWrapStyleWord(true);
			 club.setLineWrap(true);
			 club.setEditable(false);
			 avalib.setWrapStyleWord(true);
			 avalib.setLineWrap(true);
			 avalib.setEditable(false);
			frame.add(depart);
			frame.add(avalib);
			frame.add(club);
			frame.add(direct); 
			frame.add(placeholder);
			depart.setLocation(20, 100);
			avalib.setLocation(20, 140);
			club.setLocation(20, 180);
			direct.setLocation(60, 220);
			 g.drawImage(image, 10, 10, this);
		    

			g.drawRect(10, 10, 250, 250);
			g.drawRect( 260 , 10, 230, 250);
			
			//sets font for title and prints
			g.setFont(new Font("SansSerif", Font.PLAIN, 40));
			g.drawString("Room " + roomNumber , 20 , 55);
			
			//sets font for info and prints
			g.setFont(new Font("SansSerif", Font.PLAIN, 20));
			g.drawString(teacher, 20, 80);
			
			//frame.add(null);
			//g.drawString(department , 20, 100);
		//	g.drawString(avaliblity.substring(0,avaliblity.length()/2), 20, 140);
			//g.drawString(avaliblity.substring(avaliblity.length()/2), 20, 155);
			//g.drawString(clubs.substring(0,clubs.length()/2), 20, 200);
			//g.drawString(clubs.substring(clubs.length()/2), 20, 220);
		    
		}
	
	public static void roomPop(String description) throws IOException {
		int roomnumber;
		Scanner input = new Scanner(description);
		if (input.next()=="Gym") {
			roomnumber = 86;
		}
		else {
			roomnumber = input.nextInt();
		}
		//calls dinos reader and parses it 
		String call= ReadExcelDemo.ExcelFileReader(roomnumber);
		Scanner in = new Scanner(call);
		in.useDelimiter("~");
		in.next();		
		//Assigns it class declarations
		teacher =in.next();
		department=in.next(); 
		availability=in.next(); 
		clubs=in.next(); 
		roomNumber = ""+roomnumber;
		System.out.printf("teacher: %s, department: %s, availability: %s, clubs: %s, roonumber: %d",
				teacher, department, availability, clubs, roomnumber);
		frame= new JFrame();		
		
		//sets up the frame
		frame.getContentPane().add(new classPopup());
		frame.setSize(510, 300);
		Point mouseX = MouseInfo.getPointerInfo().getLocation();			
		frame.setLocation(mouseX);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);	
		
		//JP = new JPanel();
		//JP.setSize(100, 30);
		//JP.setLocation(5000, 500);
		//frame.add(JP);
		
		
	}
	
	// pay no attention to this, this is now garbage but i became emotionally attached to it so it stays 
	public static void popup(String teacher, String department, String avaliblity, String clubs, int roomnumber){
		// JPanel infoPanel = new JPanel();
		// BufferedImage image = (BufferedImage) Toolkit.getDefaultToolkit().getImage("fitzvo.jpg");
		    //ImageObserver componentObtainingGraphicsFrom = null;
			//g.drawImage(image, 10, 10, null);
	
			//g.drawRect(10, 10, 250, 250);
			//g.drawRect( 260 , 10, 230, 250);
			
			//g.drawString("Room 44" , 20 , 55);
			//g.drawString("Fitzgerald, Vo", 20, 75);
			//g.drawString("Science, Journalism" , 20, 95);
			//g.drawString("Hours 2:30 - 3:30 on Fridays, Appointments", 20, 135);
			//g.drawString("from Monday to Thursday", 20, 155);
			//g.drawString("Clubs: DECA", 20, 195);
		//return infoPanel;
		//1. Create the frame.	
		/*		JFrame frame = new JFrame();
				//places it on the screenq
				Point mouseX = MouseInfo.getPointerInfo().getLocation();			
				frame.setLocation(mouseX);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				//makes panels for the information and title
				 JPanel titlePanel = new JPanel();
				 JPanel infoPanel = new JPanel();
				 infoPanel.setLayout(new BorderLayout());
				 JPanel info2Panel = new JPanel();
				 info2Panel.setLayout(new BorderLayout());
				 //makes the button 
				 JButton direct = new JButton("Direct to");
				 // creates the fonts
				 Font titleFont = new Font(infoPanel.getFont().getName(), infoPanel.getFont().getStyle(), 40);
				 Font basicFont = new Font(infoPanel.getFont().getName(), infoPanel.getFont().getStyle(), 25);
				 // makes the panel for the words
				 JTextArea titleLabel = new JTextArea("Room number " + roomnumber);
				 JLabel teacherLabel = new JLabel("Teacher: " + teacher);
				 JLabel departmentLabel =new JLabel("Department: " + department);
				 JLabel avaliblityLabel = new JLabel("Avaliblity: " + avaliblity);
				 JLabel clubsLabel = new JLabel("Clubs: " + clubs);
				 // set the font
				 titleLabel.setFont(titleFont);
				 teacherLabel.setFont(basicFont);
				 departmentLabel.setFont(basicFont);
				 avaliblityLabel.setFont(basicFont);
				 clubsLabel.setFont(basicFont);
				 // adds to the info panel
				 titlePanel.add(BorderLayout.NORTH,titleLabel);
				 infoPanel.add(BorderLayout.NORTH,teacherLabel);
				 infoPanel.add(BorderLayout.CENTER,departmentLabel);
				 infoPanel.add(BorderLayout.SOUTH,avaliblityLabel);
				 info2Panel.add(BorderLayout.SOUTH,clubsLabel);
				 titlePanel.add(BorderLayout.EAST,direct);
				 // add the frame
				 frame.add(BorderLayout.NORTH,titlePanel);		 
				 frame.add(BorderLayout.CENTER,infoPanel); 
				 frame.add(BorderLayout.SOUTH,info2Panel); 
				 
				 frame.getContentPane().add(BorderLayout.NORTH,titlePanel);
				 frame.getContentPane().add(BorderLayout.CENTER,infoPanel);
				 frame.getContentPane().add(BorderLayout.SOUTH,info2Panel);

				// Size the frame.
				frame.pack();
				frame.setResizable(false);
				frame.setIconImages(null);
				// Show it.
				frame.setVisible(true);
				*/
	}
	
}

